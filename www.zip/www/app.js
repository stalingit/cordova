App = function()
{
           this.tempo=180; 
       
    // this is where the WADE app is initialized
	this.init = function()
	{
             
          wade.loadScene('preload.wsc', false, function()
        {   
	          
	          	wade.loadScene('hog_home_page.wsc', true, function()
        {
           
 wade.loadImage('loader-bg.jpg');
    wade.loadImage('loader-logo.png');

wade.loadImage('loader-button.png');

wade.loadImage('progress_bar_png.png');

wade.loadImage('progress_bar_png.gif');

wade.loadImage('front-page.jpg');


wade.loadImage('play-button.jpg');

wade.loadImage('text-page.jpg');

wade.loadImage('playnow-button.jpg');




wade.loadImage('TEXT-LOGO.png');

wade.loadImage('help-button.png');

wade.loadImage('unsound-button.png');

wade.loadImage('sound-button.png');


wade.loadImage('timer.png');
wade.loadImage('level-complete.png');


wade.loadImage('level1/level1-bg.jpg');

wade.loadImage('level1/level1-full.jpg');

wade.loadImage('level1/level1-objs.png');


wade.loadImage('level2/level2-bg.jpg');

wade.loadImage('level2/level2-full.jpg');

wade.loadImage('level2/level2-objs.png');


wade.loadImage('level3/level3-bg.jpg');

wade.loadImage('level3/level3-full.jpg');

wade.loadImage('level3/level3-objs.png');



wade.loadImage('hiddenObject_1/base_0.png');
wade.loadImage('hiddenObject_1/base_1.png');
wade.loadImage('hiddenObject_1/base_2.png');
wade.loadImage('hiddenObject_1/base_3.png');
wade.loadImage('hiddenObject_1/base_4.png');
wade.loadImage('hiddenObject_1/base_5.png');
wade.loadImage('hiddenObject_1/base_6.png');
wade.loadImage('hiddenObject_1/base_7.png');
wade.loadImage('hiddenObject_1/base_8.png');
wade.loadImage('hiddenObject_1/base_9.png');
wade.loadImage('hiddenObject_1/base_10.png');
wade.loadImage('hiddenObject_1/base_11.png');




wade.loadImage('hiddenObject_1/mask_0.png');
wade.loadImage('hiddenObject_1/mask_1.png');
wade.loadImage('hiddenObject_1/mask_2.png');
wade.loadImage('hiddenObject_1/mask_3.png');
wade.loadImage('hiddenObject_1/mask_4.png');
wade.loadImage('hiddenObject_1/mask_5.png');
wade.loadImage('hiddenObject_1/mask_6.png');
wade.loadImage('hiddenObject_1/mask_7.png');
wade.loadImage('hiddenObject_1/mask_8.png');
wade.loadImage('hiddenObject_1/mask_9.png');
wade.loadImage('hiddenObject_1/mask_10.png');
wade.loadImage('hiddenObject_1/mask_11.png');

wade.loadImage('hiddenObject_1/obj_0.png');
wade.loadImage('hiddenObject_1/obj_1.png');
wade.loadImage('hiddenObject_1/obj_2.png');
wade.loadImage('hiddenObject_1/obj_3.png');
wade.loadImage('hiddenObject_1/obj_4.png');
wade.loadImage('hiddenObject_1/obj_5.png');
wade.loadImage('hiddenObject_1/obj_6.png');
wade.loadImage('hiddenObject_1/obj_7.png');
wade.loadImage('hiddenObject_1/obj_8.png');
wade.loadImage('hiddenObject_1/obj_9.png');
wade.loadImage('hiddenObject_1/obj_10.png');
wade.loadImage('hiddenObject_1/obj_11.png');




wade.loadImage('hiddenObject_2/base_0.png');
wade.loadImage('hiddenObject_2/base_1.png');
wade.loadImage('hiddenObject_2/base_2.png');
wade.loadImage('hiddenObject_2/base_3.png');
wade.loadImage('hiddenObject_2/base_4.png');
wade.loadImage('hiddenObject_2/base_5.png');
wade.loadImage('hiddenObject_2/base_6.png');
wade.loadImage('hiddenObject_2/base_7.png');
wade.loadImage('hiddenObject_2/base_8.png');
wade.loadImage('hiddenObject_2/base_9.png');
wade.loadImage('hiddenObject_2/base_10.png');
wade.loadImage('hiddenObject_2/base_11.png');




wade.loadImage('hiddenObject_2/mask_0.png');
wade.loadImage('hiddenObject_2/mask_1.png');
wade.loadImage('hiddenObject_2/mask_2.png');
wade.loadImage('hiddenObject_2/mask_3.png');
wade.loadImage('hiddenObject_2/mask_4.png');
wade.loadImage('hiddenObject_2/mask_5.png');
wade.loadImage('hiddenObject_2/mask_6.png');
wade.loadImage('hiddenObject_2/mask_7.png');
wade.loadImage('hiddenObject_2/mask_8.png');
wade.loadImage('hiddenObject_2/mask_9.png');
wade.loadImage('hiddenObject_2/mask_10.png');
wade.loadImage('hiddenObject_2/mask_11.png');

wade.loadImage('hiddenObject_2/obj_0.png');
wade.loadImage('hiddenObject_2/obj_1.png');
wade.loadImage('hiddenObject_2/obj_2.png');
wade.loadImage('hiddenObject_2/obj_3.png');
wade.loadImage('hiddenObject_2/obj_4.png');
wade.loadImage('hiddenObject_2/obj_5.png');
wade.loadImage('hiddenObject_2/obj_6.png');
wade.loadImage('hiddenObject_2/obj_7.png');
wade.loadImage('hiddenObject_2/obj_8.png');
wade.loadImage('hiddenObject_2/obj_9.png');
wade.loadImage('hiddenObject_2/obj_10.png');
wade.loadImage('hiddenObject_2/obj_11.png');




wade.loadImage('hiddenObject_3/base_0.png');
wade.loadImage('hiddenObject_3/base_1.png');
wade.loadImage('hiddenObject_3/base_2.png');
wade.loadImage('hiddenObject_3/base_3.png');
wade.loadImage('hiddenObject_3/base_4.png');
wade.loadImage('hiddenObject_3/base_5.png');
wade.loadImage('hiddenObject_3/base_6.png');
wade.loadImage('hiddenObject_3/base_7.png');
wade.loadImage('hiddenObject_3/base_8.png');
wade.loadImage('hiddenObject_3/base_9.png');
wade.loadImage('hiddenObject_3/base_10.png');
wade.loadImage('hiddenObject_3/base_11.png');




wade.loadImage('hiddenObject_3/mask_0.png');
wade.loadImage('hiddenObject_3/mask_1.png');
wade.loadImage('hiddenObject_3/mask_2.png');
wade.loadImage('hiddenObject_3/mask_3.png');
wade.loadImage('hiddenObject_3/mask_4.png');
wade.loadImage('hiddenObject_3/mask_5.png');
wade.loadImage('hiddenObject_3/mask_6.png');
wade.loadImage('hiddenObject_3/mask_7.png');
wade.loadImage('hiddenObject_3/mask_8.png');
wade.loadImage('hiddenObject_3/mask_9.png');
wade.loadImage('hiddenObject_3/mask_10.png');
wade.loadImage('hiddenObject_3/mask_11.png');

wade.loadImage('hiddenObject_3/obj_0.png');
wade.loadImage('hiddenObject_3/obj_1.png');
wade.loadImage('hiddenObject_3/obj_2.png');
wade.loadImage('hiddenObject_3/obj_3.png');
wade.loadImage('hiddenObject_3/obj_4.png');
wade.loadImage('hiddenObject_3/obj_5.png');
wade.loadImage('hiddenObject_3/obj_6.png');
wade.loadImage('hiddenObject_3/obj_7.png');
wade.loadImage('hiddenObject_3/obj_8.png');
wade.loadImage('hiddenObject_3/obj_9.png');
wade.loadImage('hiddenObject_3/obj_10.png');
wade.loadImage('hiddenObject_3/obj_11.png');


wade.loadImage('firework1Green.png');

wade.loadImage('top_bar.png');

wade.loadAudio('Click2.wav');

wade.loadAudio('bg.wav');


























        });
  });
	          
	   
	
       

	};
	this.load =function(){
   	};

};
